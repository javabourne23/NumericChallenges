/*
 * 
 * Challenge:
 * 
 * Given: int[] a
 * Minimize the value |(A[0] + ... + A[P-1]) - (A[P] + ... + A[N-1])|.
 * Gegeben ist ein Array. Dieses soll so an einer bestimmten Position in  2 Arrays geteilt werden,
 * dass die Differenz zw. diesen beiden Arrays im Betrag minimal ist.
 * 
 * Testcases:
 * vorgegeben (z. B. {10,0,0,3,5,15}) sowie 
 * mit bef�lltem Array {1, 2, 3, ... , n}
 * 
 * 
 * author: MarkusG
 * 
 */


package minArray;

public class MinArrayMarkusG {

	public static void main(String[] args) {
		int[] a = {1,2,3,4,5};		// expected: 3
		int[] b = {10,0,0,3,5,15};			// expected: 3
		int[] c = {0,0,100, 2, 10, 25};			// expected: 63
		
		int[] d = {1000,0,100, 2, 10, 25};		// expected: 863
		int[] e = {0,0,100, 2, 0, 0, 10, 25};	// expected: 63
		int[] f = {0,0,100, 2, 10, 25, 62};		// expected: 1
		
		int[] g = new int[10];					// bef�llen: von 1 bis n
		for (int i = 0; i<g.length; i++) {
			g[i] = i+1;
		}

		System.out.println("min von a: " + solution(a) );
		System.out.println("min von b: " + solution(b) );
		System.out.println("min von c: " + solution(c) );
		System.out.println("min von d: " + solution(d) );
		System.out.println("min von e: " + solution(e) );
		System.out.println("min von f: " + solution(f) );
		
		System.out.println("min von g: " + solution(g) );

	}
	
	public static int solution (int[] a) {
		int minValue = -9999;	// finale min. Differenz
		int difference;
		int indexposition;		// finale Indexposition
		
		int j = a.length/2;		// Startindex j in der Arraymitte, f�r L�sungen ab g nach rechts
		difference = summeArray (a) - 2 * summeBisIndex (a, j); 			// summeRechts - summeLinks
		System.out.println("Difference: " + difference);
		while (j < a.length)
		if (difference == 0) {
			minValue = difference; indexposition = j; return minValue;
		} else if (difference > 0){
			while (difference > 0) {
				minValue = difference;
				difference -= 2 * a[j];
				j++;				
			}
		minValue = Math.min(minValue, Math.abs(difference));
			// etv. Index ermitteln
		return minValue;	
		} else if (difference < 0){
			while (difference < 0) {
				minValue = difference;
				difference += 2 * a[j-1];
				j--;
			}
		minValue = Math.min(Math.abs(minValue), Math.abs(difference));	
		}
	return minValue;
	}
	
	public static int summeArray (int[] a) {
		int sum = 0;
		for (int j=0; j<a.length; j++) {
			sum += a[j];
		}
//		System.out.println("Gesamtsumme: " + sum);
		return sum;
	}
	
	public static int summeBisIndex (int[] a, int i) {
		int sum = 0;
		for (int j=0; j<i; j++) {
			sum += a[j];
		}
		System.out.println("Summelinks: " + sum);
		return sum;
	}

}
