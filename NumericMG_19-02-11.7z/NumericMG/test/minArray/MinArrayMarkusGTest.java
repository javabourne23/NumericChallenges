package minArray;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Before;
import org.junit.Test;

public class MinArrayMarkusGTest {
	
		int[] a = {1,2,3,4,5};		// expected: 3
		int[] b = {10,0,0,3,5,15};			// expected: 3
		int[] c = {0,0,100, 2, 10, 25};			// expected: 63
		
		int[] d = {1000,0,100, 2, 10, 25};		// expected: 863
		int[] e = {0,0,100, 2, 0, 0, 10, 25};	// expected: 63
		int[] f = {0,0,100, 2, 10, 25, 62};		// expected: 1
		
		int n1  = 10;					// expected: 1
		int[] g =  new int[n1];
		
		int n2 = 15;					// expected: 10
		int[] h = new int[n2];
		
		int n3 = 20;
		int[] k = new int[n3];
		
		int n4 = 100;					// expected: 62
		int[] l = new int[n4];
		
		int n5 = 1000000;				// expected: 102060
		int[] m = new int[n5];
		
		int n6 = 1000000000;			// expected: 371654656
		int[] n = new int[n6];
		
	@Before
	public void setUpBeforeClass() throws Exception {
	}


	@Test
	public void testSolution1() {
		MinArrayMarkusG mina = new MinArrayMarkusG();
		Assert.assertTrue(mina.solution(a)==3);
	}
	
	@Test
	public void testSolution2() {
		MinArrayMarkusG mina = new MinArrayMarkusG();
		Assert.assertTrue(mina.solution(b)==3);
	}

	@Test
	public void testSolution3() {
		MinArrayMarkusG mina = new MinArrayMarkusG();
		Assert.assertTrue(mina.solution(c)==63);
	}
	
	@Test
	public void testSolution4() {
		MinArrayMarkusG mina = new MinArrayMarkusG();
		Assert.assertTrue(mina.solution(d)==863);
	}
	
	@Test
	public void testSolution5() {
		MinArrayMarkusG mina = new MinArrayMarkusG();
		Assert.assertTrue(mina.solution(e)==63);
	}
	
	@Test
	public void testSolution6() {
		MinArrayMarkusG mina = new MinArrayMarkusG();
		Assert.assertTrue(mina.solution(f)==1);
	}
	
	@Test
	public void testSolution7() {
		MinArrayMarkusG mina = new MinArrayMarkusG();
		for (int i=0; i<g.length; i++) {
			g[i]=i+1;
		}
		Assert.assertTrue(mina.solution(g)==1);
	}
	
	@Test
	public void testSolution8() {
		MinArrayMarkusG mina = new MinArrayMarkusG();
		for (int i=0; i<l.length; i++) {
			l[i]=i+1;
		}
		Assert.assertTrue(mina.solution(l)==62);
	}
	
//	@Test
	public void testSolution9() {
		MinArrayMarkusG mina = new MinArrayMarkusG();
		for (int i=0; i<n.length; i++) {
			n[i]=i+1;
		}
		Assert.assertTrue(mina.solution(n)==371654656);
	}
}
